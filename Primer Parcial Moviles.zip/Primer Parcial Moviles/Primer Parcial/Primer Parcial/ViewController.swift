//
//  ViewController.swift
//  Primer Parcial
//
//  Created by Alumno on 9/20/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let secuenaciMurcielago = [
        UIImage(named: "Murcielago1")!,
        UIImage(named: "Murcielago2")!,
        UIImage(named: "Murcielago3")!,
        UIImage(named: "Murcielago4")!,
        UIImage(named: "Murcielago5")!
        ]
    
    let secuenciaKiwi = [
        UIImage(named: "Kiwi1")!,
        UIImage(named: "Kiwi2")!,
        UIImage(named: "Kiwi3")!,
        UIImage(named: "Kiwi4")!,
        UIImage(named: "Kiwi5")!
        ]
    
    let secuenciaCocodrilo = [
        UIImage(named: "CroComiendo1square")!,
        UIImage(named: "CroComiendo2square")!,
        UIImage(named: "CroComiendo3square")!,
        UIImage(named: "CroComiendo4square")!,
        UIImage(named: "CroComiendo5square")!
        ]
    
    
    
    @IBOutlet weak var imgAnimacionCocodrilo: UIImageView!
    
    @IBOutlet weak var imgAnimacionMurcielago: UIImageView!
    
    @IBOutlet weak var imgAnimacionKiwi:
        UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func DoTapCocodrilo(_ sender: Any) {
        imgAnimacionCocodrilo.animationImages = secuenciaCocodrilo
        imgAnimacionCocodrilo.animationDuration = 1.0
        imgAnimacionCocodrilo.startAnimating()
    }
    
    @IBAction func DoTapMurcielago(_ sender: Any) {
        imgAnimacionMurcielago.animationImages = secuenaciMurcielago
        imgAnimacionMurcielago.animationDuration = 1.0
        imgAnimacionMurcielago.startAnimating()
        }
    
    @IBAction func DoTapKiwi(_ sender: Any) {
        imgAnimacionKiwi.animationImages = secuenciaKiwi
        imgAnimacionKiwi.animationDuration = 1.0
        imgAnimacionKiwi.startAnimating()
    }
    

}

